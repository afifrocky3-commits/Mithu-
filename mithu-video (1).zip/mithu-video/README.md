# মিঠু ও জাদুর বটগাছ — Remotion প্রজেক্ট (9:16, 1080x1920, 30fps, 3978 ফ্রেম)

1. `npm install`
2. প্রিভিউ: `npx remotion studio`
3. রেন্ডার: `npx remotion render MithuVideo out/mithu.mp4`

ভয়েসওভার: public/voice.mp3 — টাইমিং: src/data.ts (ক্যাপশন/বাবল) ও src/scenes/*.tsx।
Remotion ভার্সন মিসম্যাচ সতর্কতা এলে `npx remotion upgrade` চালান।
