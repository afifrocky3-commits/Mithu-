import React, {createContext, useContext} from "react";
import {AbsoluteFill, Easing, Sequence, interpolate, useCurrentFrame} from "remotion";

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const TOTAL = 3978; // 132.6s voiceover
export const fr = (s: number) => Math.round(s * FPS);

const AbsCtx = createContext(0);
/** absolute frame/time of the whole video, even inside a Scene */
export const useT = () => {
  const rel = useCurrentFrame();
  const off = useContext(AbsCtx);
  const f = rel + off;
  return {f, t: f / FPS};
};
export const tw = (t: number, a: number, b: number, from = 0, to = 1) =>
  interpolate(t, [a, b], [from, to], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.inOut(Easing.cubic)});

const FadeIn: React.FC<{pre: number; children: React.ReactNode}> = ({pre, children}) => {
  const rel = useCurrentFrame();
  const o = pre ? interpolate(rel, [0, pre], [0, 1], {extrapolateRight: "clamp"}) : 1;
  return <AbsoluteFill style={{opacity: o, overflow: "hidden"}}>{children}</AbsoluteFill>;
};

/** Scene window in seconds (absolute). Starts 8 frames early for a soft crossfade. */
export const Scene: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const pre = from > 0 ? 8 : 0;
  const start = fr(from) - pre;
  const dur = Math.min(TOTAL, fr(to)) - start;
  return (
    <Sequence from={start} durationInFrames={dur}>
      <AbsCtx.Provider value={start}>
        <FadeIn pre={pre}>{children}</FadeIn>
      </AbsCtx.Provider>
    </Sequence>
  );
};
