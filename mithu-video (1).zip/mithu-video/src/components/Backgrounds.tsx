import React, {useId} from "react";
import {AbsoluteFill, interpolateColors, useCurrentFrame} from "remotion";
import {OUT} from "../theme";
import {H, W} from "../timing";

type C3 = [string, string, string];
const pick = (m: number, a: C3) => interpolateColors(m, [0, 1, 2], a);
const clamp = (n: number) => Math.max(0, Math.min(1, n));

/** ঝুরির (x, শুরুর y, দৈর্ঘ্য) */
export const JH: [number, number, number][] = [[520, 820, 330], [610, 860, 400], [700, 880, 300], [880, 900, 380], [980, 880, 300], [1050, 860, 360]];
export const PAPER_POS = {x: 612, y: 1262};
const STARS: [number, number][] = [[90, 200], [260, 120], [420, 260], [560, 150], [700, 90], [820, 240], [960, 140], [1020, 330], [160, 440], [360, 420], [520, 380], [60, 600]];
const TREE_C: [number, number, number][] = [[780, 640, 230], [560, 760, 170], [980, 720, 200], [900, 470, 190], [660, 520, 150]];

/** ফুল-স্ক্রিন গ্রামের পুকুরপাড় + বটগাছ। mix: 0 দিন, 1 সন্ধ্যা, 2 রাত */
export const Pond: React.FC<{mix?: number}> = ({mix = 0}) => {
  const f = useCurrentFrame();
  const id = useId().replace(/:/g, "");
  const m = Math.max(0, Math.min(2, mix));
  const c = {
    skyTop: pick(m, ["#8FD3FF", "#FF9E7A", "#1B2559"]),
    skyBot: pick(m, ["#E3F6FF", "#FFD9A0", "#3A4A8C"]),
    ground: pick(m, ["#79C46A", "#6FAF5E", "#2C5A47"]),
    hill: pick(m, ["#9AD68A", "#8DBF74", "#2F6650"]),
    water: pick(m, ["#6EC6F0", "#8FB8D8", "#2C4F8C"]),
    canopy: pick(m, ["#3E9B4F", "#4B8A48", "#1F5A3E"]),
    canopy2: pick(m, ["#5DBB63", "#6BA25C", "#2F7A52"]),
    trunk: pick(m, ["#8B5E3C", "#7A5232", "#4A3426"]),
  };
  const day = clamp(1 - m);
  const night = clamp(m - 1);
  return (
    <AbsoluteFill>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <linearGradient id={`sky${id}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={c.skyTop} />
            <stop offset="1" stopColor={c.skyBot} />
          </linearGradient>
        </defs>
        <rect width={W} height={H} fill={`url(#sky${id})`} />
        {STARS.map(([x, y], i) => (
          <circle key={i} cx={x} cy={y} r={5} fill="#FFF8C4" opacity={night * (0.5 + 0.5 * Math.sin(f / 10 + i))} />
        ))}
        <circle cx={190} cy={330 + Math.min(m, 1) * 140} r={140} fill="#FFE9A8" opacity={0.5 * clamp(2 - m) * (1 - night)} />
        <circle cx={190} cy={330 + Math.min(m, 1) * 140} r={88} fill="#FFD84D" opacity={clamp(2 - m) * (1 - night)} />
        <g opacity={night}>
          <circle cx={190} cy={330} r={82} fill="#FFF3C4" />
          <circle cx={165} cy={310} r={14} fill="#EBDDA0" />
          <circle cx={215} cy={355} r={10} fill="#EBDDA0" />
        </g>
        <g opacity={day * 0.95}>
          {[0, 1].map((i) => (
            <g key={i} transform={`translate(${((f * 0.5 + i * 700) % 1500) - 250},${230 + i * 150})`} fill="#fff">
              <ellipse cx={0} cy={0} rx={110} ry={45} />
              <ellipse cx={70} cy={-22} rx={70} ry={40} />
              <ellipse cx={-60} cy={-12} rx={60} ry={32} />
            </g>
          ))}
        </g>
        <path d="M0 1420Q200 1330 420 1400T820 1390T1080 1380V1500H0Z" fill={c.hill} />
        <rect y={1430} width={W} height={H - 1430} fill={c.ground} />
        {[[430, 1470], [640, 1482], [960, 1500], [80, 1462]].map(([x, y], i) => (
          <path key={i} transform={`translate(${x},${y})`} d="M0 0L-6-26L12-10L16-34L22-8L36-22L30 0Z" fill={c.hill} />
        ))}
        <ellipse cx={240} cy={1700} rx={330} ry={85} fill={c.water} stroke={OUT} strokeWidth={5} />
        <path d="M110 1690Q170 1670 230 1690" stroke="#fff" opacity={0.6} strokeWidth={6} fill="none" strokeLinecap="round" />
        {/* বটগাছ */}
        <path d="M630 1500Q690 1200 700 900L900 900Q910 1200 990 1500Z" fill={c.trunk} stroke={OUT} strokeWidth={5} />
        <path d="M740 1480Q760 1200 770 940M840 1480Q850 1220 850 940" stroke={OUT} opacity={0.35} strokeWidth={5} fill="none" />
        {TREE_C.map(([x, y, r], i) => <circle key={`o${i}`} cx={x} cy={y} r={r + 5} fill={OUT} />)}
        {TREE_C.map(([x, y, r], i) => <circle key={`c${i}`} cx={x} cy={y} r={r} fill={c.canopy} />)}
        {[[740, 600, 90], [950, 560, 80], [600, 700, 60]].map(([x, y, r], i) => <circle key={`h${i}`} cx={x} cy={y} r={r} fill={c.canopy2} opacity={0.8} />)}
        {JH.map(([x, y0, len], i) => {
          const s = Math.sin(f / 22 + i * 1.3) * 10;
          const d = `M${x} ${y0}Q${x + s} ${y0 + len / 2} ${x + s * 0.5} ${y0 + len}`;
          return (
            <g key={i} fill="none" strokeLinecap="round">
              <path d={d} stroke={OUT} strokeWidth={15} />
              <path d={d} stroke={c.trunk} strokeWidth={8} />
            </g>
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};

/** ঝোপ (৫২০×৩০০) */
export const Bush: React.FC = () => {
  const B: [number, number, number][] = [[130, 190, 100], [260, 150, 120], [390, 190, 100], [260, 230, 70]];
  return (
    <svg width={520} height={300} viewBox="0 0 520 300">
      {B.map(([x, y, r], i) => <circle key={`o${i}`} cx={x} cy={y} r={r + 5} fill={OUT} />)}
      {B.map(([x, y, r], i) => <circle key={`c${i}`} cx={x} cy={y} r={r} fill="#3E9B4F" />)}
      <circle cx={230} cy={120} r={50} fill="#5DBB63" opacity={0.8} />
    </svg>
  );
};

/** মোশন গ্রাফিক্স সিনের ক্লিন ভিনিয়েট ব্যাকগ্রাউন্ড */
export const MGBg: React.FC = () => (
  <AbsoluteFill style={{background: "radial-gradient(circle at 50% 45%, #FFF6E0 0%, #F7E3B5 60%, #E8C77F 100%)"}} />
);
