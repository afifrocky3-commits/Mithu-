import React from "react";
import {FONT, OUT} from "../theme";

export type IconName =
  | "paper" | "bag" | "book" | "bookopen" | "pillow" | "moon" | "star" | "calendar" | "torch"
  | "pencil" | "question" | "exclaim" | "check" | "zzz" | "eye" | "tree" | "notebook" | "sparkle" | "heart";

const st = {stroke: OUT, strokeWidth: 3.5, strokeLinejoin: "round" as const, strokeLinecap: "round" as const};
const txt = {fontFamily: FONT, fontWeight: 700, textAnchor: "middle" as const, stroke: "none"};

export const Icon: React.FC<{name: IconName; size?: number; label?: string}> = ({name, size = 120, label}) => {
  let g: React.ReactNode = null;
  switch (name) {
    case "paper":
      g = (<g {...st}><path d="M24 8H62L80 26V92H24Z" fill="#FFFDF5" /><path d="M62 8V26H80" fill="#E9E3CE" /><path d="M34 44H70M34 58H70M34 72H56" stroke="#4A90D9" fill="none" /></g>);
      break;
    case "bag":
      g = (<g {...st}><path d="M34 34Q14 62 26 86Q50 98 74 86Q86 62 66 34Z" fill="#D9A066" /><path d="M34 34Q50 46 66 34" fill="none" /><path d="M50 40V18" fill="none" /><circle cx="50" cy="14" r="6" fill="#fff" /></g>);
      break;
    case "book":
      g = (<g {...st}><rect x="22" y="12" width="60" height="78" rx="6" fill="#3B82F6" /><rect x="22" y="12" width="11" height="78" rx="4" fill="#2563C9" /><text x="58" y="60" fontSize="24" fill="#fff" {...txt}>অঙ্ক</text></g>);
      break;
    case "bookopen":
      g = (<g {...st}><path d="M6 26Q28 16 50 28Q72 16 94 26V80Q72 70 50 82Q28 70 6 80Z" fill="#FFFDF5" /><path d="M50 28V82" fill="none" /><path d="M16 42Q30 38 42 44M16 56Q30 52 42 58M58 44Q70 38 84 42M58 58Q70 52 84 56" stroke="#9AA3AF" fill="none" /></g>);
      break;
    case "pillow":
      g = (<g {...st}><path d="M10 38Q50 22 90 38Q80 56 90 72Q50 86 10 72Q20 56 10 38Z" fill="#CFE8FF" /><path d="M26 46Q50 54 74 46" fill="none" stroke="#8FBDEB" /></g>);
      break;
    case "moon":
      g = (<g {...st}><path d="M62 12A38 38 0 1 0 88 66A30 30 0 1 1 62 12Z" fill="#FFE27A" /></g>);
      break;
    case "star":
      g = (<g {...st}><polygon points="50,8 61,38 92,38 67,57 77,88 50,69 23,88 33,57 8,38 39,38" fill="#FFD23F" /></g>);
      break;
    case "calendar":
      g = (<g {...st}><rect x="12" y="18" width="76" height="72" rx="10" fill="#fff" /><path d="M12 28Q12 18 22 18H78Q88 18 88 28V42H12Z" fill="#E85D5D" /><path d="M32 10V26M68 10V26" fill="none" strokeWidth={6} /><text x="50" y="80" fontSize="42" fill={OUT} {...txt}>{label ?? "৩"}</text></g>);
      break;
    case "torch":
      g = (<g {...st}><path d="M30 12H70L62 40H38Z" fill="#FFD23F" /><rect x="38" y="40" width="24" height="52" rx="6" fill="#4B5563" /><path d="M38 56H62" fill="none" /></g>);
      break;
    case "pencil":
      g = (<g {...st}><rect x="40" y="6" width="20" height="14" rx="3" fill="#F29BA8" /><rect x="40" y="20" width="20" height="50" fill="#FFD23F" /><path d="M40 70H60L50 94Z" fill="#F5D5A8" /><path d="M46 85H54L50 94Z" fill={OUT} /></g>);
      break;
    case "question":
      g = (<g {...st}><circle cx="50" cy="50" r="42" fill="#FFD23F" /><text x="50" y="72" fontSize="70" fill={OUT} {...txt}>?</text></g>);
      break;
    case "exclaim":
      g = (<g {...st}><circle cx="50" cy="50" r="42" fill="#FF6B6B" /><text x="50" y="72" fontSize="70" fill="#fff" {...txt}>!</text></g>);
      break;
    case "check":
      g = (<g {...st}><circle cx="50" cy="50" r="42" fill="#3BB273" /><path d="M28 52L44 68L74 34" stroke="#fff" strokeWidth={9} fill="none" /></g>);
      break;
    case "zzz":
      g = (<text x="50" y="68" fontSize="64" fill="#fff" fontFamily={FONT} fontWeight={700} textAnchor="middle" stroke={OUT} strokeWidth={7} paintOrder="stroke fill">Zz</text>);
      break;
    case "eye":
      g = (<g {...st}><ellipse cx="50" cy="50" rx="42" ry="28" fill="#fff" /><circle cx="50" cy="50" r="17" fill={OUT} /><circle cx="56" cy="44" r="5" fill="#fff" stroke="none" /></g>);
      break;
    case "tree":
      g = (<g {...st}><path d="M42 96L44 58H56L58 96Z" fill="#8B5E3C" /><circle cx="28" cy="46" r="20" fill="#3E9B4F" /><circle cx="72" cy="46" r="20" fill="#3E9B4F" /><circle cx="50" cy="32" r="28" fill="#3E9B4F" /></g>);
      break;
    case "notebook":
      g = (<g {...st}><rect x="16" y="8" width="68" height="84" rx="6" fill="#fff" /><path d="M26 8V92" fill="none" stroke="#E85D5D" /><circle cx="56" cy="52" r="24" fill="none" stroke="#E85D5D" strokeWidth={3} /><text x="56" y="64" fontSize="34" fill="#E85D5D" {...txt}>৭৮</text></g>);
      break;
    case "sparkle":
      g = (<g {...st}><path d="M50 6Q55 45 94 50Q55 55 50 94Q45 55 6 50Q45 45 50 6Z" fill="#FFF3A0" stroke="#F0B400" /></g>);
      break;
    case "heart":
      g = (<g {...st}><path d="M50 88C8 58 12 22 34 22C44 22 50 28 50 34C50 28 56 22 66 22C88 22 92 58 50 88Z" fill="#FF6B8A" /></g>);
      break;
  }
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" style={{overflow: "visible"}}>
      {g}
    </svg>
  );
};
