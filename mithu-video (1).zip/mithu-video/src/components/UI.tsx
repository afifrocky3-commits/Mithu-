import React from "react";
import {AbsoluteFill, spring, useCurrentFrame} from "remotion";
import {FONT, OUT} from "../theme";
import {FPS, H, W, fr, tw, useT} from "../timing";
import {CAPTIONS, OVERLAYS} from "../data";
import {Icon, IconName} from "./Icons";

const clamp01 = (n: number) => Math.max(0, Math.min(1, n));

/** পপ-আপ + ভাসমান র‍্যাপার (সময় সেকেন্ডে, ভিডিওর শুরু থেকে) */
export const Pop: React.FC<{
  x: number; y: number; from: number; to: number; float?: number; rot?: number; z?: number; children: React.ReactNode;
}> = ({x, y, from, to, float = 8, rot = 0, z, children}) => {
  const {f, t} = useT();
  if (t < from || t > to + 0.3) return null;
  const sIn = spring({frame: f - fr(from), fps: FPS, config: {damping: 11, stiffness: 150}});
  const out = t > to ? clamp01(1 - (t - to) / 0.3) : 1;
  const fy = Math.sin((f - fr(from)) / 14) * float;
  return (
    <div style={{position: "absolute", left: x, top: y, zIndex: z, transform: `translate(-50%,-50%) translateY(${fy}px) rotate(${rot}deg) scale(${sIn * out})`}}>
      {children}
    </div>
  );
};

export const IP: React.FC<{
  name: IconName; x: number; y: number; from: number; to: number; size?: number; label?: string; float?: number; rot?: number; z?: number;
}> = ({name, size = 140, label, ...r}) => (
  <Pop {...r}>
    <Icon name={name} size={size} label={label} />
  </Pop>
);

export const Ring: React.FC<{x: number; y: number; from: number; to: number; size?: number}> = ({x, y, from, to, size = 190}) => {
  const {f} = useT();
  const p = (f % 24) / 24;
  return (
    <Pop x={x} y={y} from={from} to={to} float={0}>
      <div style={{width: size, height: size, borderRadius: "50%", border: "10px dashed #FFD23F", boxShadow: "0 0 30px #FFD23F", transform: `scale(${1 + 0.15 * Math.sin(p * Math.PI * 2)})`}} />
    </Pop>
  );
};

/** স্পিচ কলআউট বাবল — লেজের ডগা (tipX, tipY) বক্তার দিকে */
export const Bubble: React.FC<{
  from: number; to: number; tipX: number; tipY: number; w?: number; text: string; bg?: string;
}> = ({from, to, tipX, tipY, w = 820, text, bg = "#FFFFFF"}) => {
  const {f, t} = useT();
  if (t < from || t > to + 0.25) return null;
  const left = Math.max(36, Math.min(W - 36 - w, tipX - w / 2));
  const tailX = Math.max(70, Math.min(w - 70, tipX - left));
  const s = spring({frame: f - fr(from), fps: FPS, config: {damping: 12, stiffness: 160}}) * clamp01(1 - (t - to) / 0.25);
  return (
    <div
      style={{
        position: "absolute", left, bottom: H - (tipY - 50), width: w, boxSizing: "border-box",
        transformOrigin: `${tailX}px 100%`, transform: `scale(${s})`, background: bg,
        border: `6px solid ${OUT}`, borderRadius: 48, padding: "28px 36px", fontFamily: FONT,
        fontWeight: 700, fontSize: 68, lineHeight: 1.25, textAlign: "center", color: OUT,
      }}
    >
      {text}
      <svg width={60} height={62} style={{position: "absolute", left: tailX - 36, top: "calc(100% - 2px)", overflow: "visible"}}>
        <path d="M6 4L30 58L54 4" fill={bg} stroke={OUT} strokeWidth={6} strokeLinejoin="round" />
        <path d="M10 4H50" stroke={bg} strokeWidth={10} />
      </svg>
    </div>
  );
};

/** উপরের লোকেশন/সময় পিল */
export const Pill: React.FC<{from: number; to: number; text: string; color?: string}> = ({from, to, text, color = "#FFFFFF"}) => {
  const {f, t} = useT();
  if (t < from || t > to + 0.3) return null;
  const p = spring({frame: f - fr(from), fps: FPS, config: {damping: 14}}) * clamp01(1 - (t - to) / 0.3);
  return (
    <div style={{position: "absolute", top: 130, left: 0, right: 0, display: "flex", justifyContent: "center", opacity: p, transform: `translateY(${(1 - p) * -80}px)`}}>
      <span style={{background: color, border: `5px solid ${OUT}`, borderRadius: 60, padding: "12px 44px", fontFamily: FONT, fontWeight: 700, fontSize: 54, color: OUT}}>{text}</span>
    </div>
  );
};

export const NameBadge: React.FC<{text: string; color: string}> = ({text, color}) => (
  <span style={{display: "inline-block", background: color, color: "#fff", border: `5px solid ${OUT}`, borderRadius: 50, padding: "10px 40px", fontFamily: FONT, fontWeight: 700, fontSize: 52, whiteSpace: "nowrap"}}>{text}</span>
);

/** ক্যামেরা জুম / স্ক্রিন শেক */
export const Camera: React.FC<{zoom?: number; ox?: number; oy?: number; shake?: number; children: React.ReactNode}> = ({zoom = 1, ox = W / 2, oy = H / 2, shake = 0, children}) => {
  const f = useCurrentFrame();
  const sx = shake ? Math.sin(f * 3.1) * shake : 0;
  const sy = shake ? Math.cos(f * 4.3) * shake : 0;
  return <AbsoluteFill style={{transformOrigin: `${ox}px ${oy}px`, transform: `translate(${sx}px,${sy}px) scale(${zoom})`}}>{children}</AbsoluteFill>;
};

/** শব্দ ধরে ধরে ফুটে ওঠা টেক্সট */
export const Words: React.FC<{text: string; from: number; to: number; size: number; hi?: string[]; color?: string; hiColor?: string}> = ({text, from, to, size, hi = [], color = "#fff", hiColor = "#FFD23F"}) => {
  const {t} = useT();
  const ws = text.split(" ");
  return (
    <div style={{fontFamily: FONT, fontWeight: 700, fontSize: size, lineHeight: 1.35, textAlign: "center"}}>
      {ws.map((w, i) => {
        const p = tw(t, from + ((to - from) * i) / ws.length, from + ((to - from) * (i + 1)) / ws.length + 0.2);
        const isHi = hi.some((h) => w.includes(h));
        return (
          <span key={i} style={{display: "inline-block", marginRight: "0.3em", opacity: p, transform: `translateY(${(1 - p) * 24}px)`, color: isHi ? hiColor : color}}>{w}</span>
        );
      })}
    </div>
  );
};

export const cardStyle = (w: number): React.CSSProperties => ({
  width: w, boxSizing: "border-box", background: "#fff", border: `8px solid ${OUT}`, borderRadius: 52, padding: 36,
  display: "flex", flexDirection: "column", alignItems: "center", gap: 20, fontFamily: FONT, fontWeight: 700, color: OUT,
  boxShadow: "0 14px 0 rgba(0,0,0,0.18)",
});

/** নিচের ওভারলে ক্যাপশন — বাবল/কার্ড থাকলে লুকিয়ে যায় */
export const Caption: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cap = CAPTIONS.find((c) => t >= c.from && t < c.to);
  if (!cap) return null;
  if (OVERLAYS.some(([a, b]) => t > a - 0.05 && t < b + 0.05)) return null;
  const p = spring({frame: frame - fr(cap.from), fps: FPS, config: {damping: 14}});
  const fs = Math.max(40, Math.min(64, 960 / (cap.text.length * 0.62)));
  const parts = cap.hi.length ? cap.text.split(new RegExp(`(${cap.hi.join("|")})`)) : [cap.text];
  return (
    <div style={{position: "absolute", left: 0, right: 0, bottom: 210, textAlign: "center", opacity: Math.min(1, p), transform: `translateY(${(1 - Math.min(1, p)) * 36}px)`}}>
      <span style={{fontFamily: FONT, fontWeight: 700, fontSize: fs, color: "#fff", whiteSpace: "nowrap", WebkitTextStroke: "10px #222", paintOrder: "stroke fill"}}>
        {parts.map((s, i) => (
          <span key={i} style={{color: cap.hi.includes(s) ? "#FFD23F" : "#fff"}}>{s}</span>
        ))}
      </span>
    </div>
  );
};
