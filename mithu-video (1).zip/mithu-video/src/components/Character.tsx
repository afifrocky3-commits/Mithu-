import React from "react";
import {useCurrentFrame} from "remotion";
import {OUT, SW} from "../theme";

export type Expr = "neutral" | "happy" | "sad" | "worried" | "surprised" | "angry" | "determined" | "whisper" | "sleep" | "proud";

type P = {
  kind: "mithu" | "dadu";
  x: number; // কেন্দ্র x
  feetY: number; // পায়ের নিচের y
  scale?: number;
  expr?: Expr;
  talking?: boolean;
  armL?: number; // স্ক্রিনের বাঁ হাত: + = বাইরে/উপরে, − = ভেতরে
  armR?: number;
  handL?: React.ReactNode;
  handR?: React.ReactNode;
  walk?: boolean;
  shake?: number;
  lookX?: number;
  lean?: number;
  seed?: number;
};

const BASE = 2;
// [ভ্রু-বাঁ dy, rot, ভ্রু-ডান dy, rot]
const BROWS: Record<Expr, [number, number, number, number]> = {
  neutral: [0, 0, 0, 0], happy: [-5, -6, -5, 6], sad: [2, -20, 2, 20], worried: [-2, -16, -2, 16],
  surprised: [-12, 0, -12, 0], angry: [4, 18, 4, -18], determined: [3, 12, 3, -12],
  whisper: [0, -6, 0, 6], sleep: [2, 0, 2, 0], proud: [-4, -4, -4, 4],
};
const S = {stroke: OUT, strokeWidth: SW, strokeLinejoin: "round" as const, strokeLinecap: "round" as const};

const Mouth: React.FC<{expr: Expr; phase: number}> = ({expr, phase}) => {
  const line = {fill: "none", stroke: OUT, strokeWidth: 4.5, strokeLinecap: "round" as const};
  if (phase === 1) return <ellipse cx={0} cy={4} rx={9} ry={7} fill="#7A1F2B" stroke={OUT} strokeWidth={3} />;
  if (phase === 2)
    return (
      <g>
        <ellipse cx={0} cy={6} rx={14} ry={14} fill="#7A1F2B" stroke={OUT} strokeWidth={3} />
        <ellipse cx={0} cy={14} rx={8} ry={5} fill="#E86A7A" />
      </g>
    );
  switch (expr) {
    case "happy":
    case "proud":
      return <path d="M-20 -2Q0 26 20 -2Z" fill="#7A1F2B" stroke={OUT} strokeWidth={3.5} strokeLinejoin="round" />;
    case "sad": return <path d="M-16 10Q0 -6 16 10" {...line} />;
    case "worried": return <path d="M-16 8Q-8 0 0 8T16 8" {...line} />;
    case "surprised": return <ellipse cx={0} cy={6} rx={8} ry={11} fill="#7A1F2B" stroke={OUT} strokeWidth={3} />;
    case "angry": return <path d="M-14 8Q0 -2 14 8" {...line} />;
    case "determined": return <path d="M-14 3H14" {...line} />;
    case "whisper": return <path d="M-6 3Q0 7 6 3" {...line} />;
    case "sleep": return <ellipse cx={0} cy={5} rx={6} ry={5} fill="#7A1F2B" stroke={OUT} strokeWidth={3} />;
    default: return <path d="M-14 0Q0 12 14 0" {...line} />;
  }
};

export const Character: React.FC<P> = ({
  kind, x, feetY, scale = 1, expr = "neutral", talking = false, armL = 6, armR = 6,
  handL, handR, walk = false, shake = 0, lookX = 0, lean, seed = 0,
}) => {
  const frame = useCurrentFrame();
  const M = kind === "mithu";
  const k = BASE * scale;
  const footY = M ? 440 : 503;
  const skin = M ? "#E9B58B" : "#D9A074";
  const sw = walk ? Math.sin(frame * 0.5) : 0;
  const bob = walk ? -Math.abs(sw) * 8 : Math.sin((frame + seed * 13) / 14) * 4;
  const jx = shake ? Math.sin(frame * 5.1 + seed) * shake : 0;
  const jy = shake ? Math.cos(frame * 6.7) * shake * 0.6 : 0;
  const blink = (frame + seed * 23) % 100 < 4;
  const phase = talking ? [0, 1, 2, 1, 2, 1, 0, 2][Math.floor(frame / 3) % 8] : 0;
  const [dyL, rL, dyR, rR] = BROWS[expr];
  const eyeMode = expr === "sleep" ? "closed" : expr === "happy" || expr === "proud" ? "happy" : "open";
  const ex = M ? 24 : 22;
  const erx = M ? 17 : 12;
  const ery = M ? 21 : 13;
  const pr = M ? 8 : 5;
  const wide = expr === "surprised" ? 1.18 : 1;
  const browY = M ? -34 : -30;
  const mouthY = M ? 32 : 38;
  const leanDeg = lean ?? (M ? 0 : 2);

  const Eye = (cx: number) => {
    if (eyeMode === "open")
      return (
        <g transform={`translate(${cx},-2) scale(${wide},${blink ? 0.1 : wide})`}>
          <ellipse rx={erx} ry={ery} fill="#fff" stroke={OUT} strokeWidth={SW} />
          <circle cx={lookX * 5} cy={0} r={expr === "surprised" ? pr * 0.7 : pr} fill={OUT} />
          <circle cx={lookX * 5 + 2} cy={-2} r={2} fill="#fff" />
        </g>
      );
    const d = eyeMode === "happy" ? `M${cx - 13} 4Q${cx} -14 ${cx + 13} 4` : `M${cx - 13} -2Q${cx} 8 ${cx + 13} -2`;
    return <path d={d} fill="none" stroke={OUT} strokeWidth={4.5} strokeLinecap="round" />;
  };
  const Brow = (cx: number, dy: number, rot: number) => (
    <g transform={`translate(${cx},${browY + dy}) rotate(${rot})`}>
      {!M && <line x1={-14} x2={14} stroke={OUT} strokeWidth={10} strokeLinecap="round" />}
      <line x1={-13} x2={13} stroke={M ? OUT : "#F2F2F2"} strokeWidth={M ? 5 : 6} strokeLinecap="round" />
    </g>
  );

  const Leg = (i: number) => {
    const hx = i ? 173 : 127;
    const a = (i ? -sw : sw) * 22;
    const hipY = M ? 292 : 320;
    return (
      <g key={i} transform={`rotate(${a} ${hx} ${hipY})`}>
        <rect x={hx - 15} y={hipY - 6} width={30} height={M ? 138 : 176} rx={15} fill={skin} {...S} />
        {M ? (
          <ellipse cx={hx + (i ? 4 : -4)} cy={428} rx={24} ry={10} fill="#222" stroke={OUT} strokeWidth={SW} />
        ) : (
          <ellipse cx={hx + (i ? 4 : -4)} cy={492} rx={26} ry={11} fill={skin} {...S} />
        )}
      </g>
    );
  };

  const Arm = (side: 0 | 1, angle: number, prop: React.ReactNode) => {
    const len = M ? 92 : 100;
    const sleeve = M ? 40 : 92;
    const shirt = M ? "#FFD23F" : "#FFFFFF";
    return (
      <g transform={`translate(${side === 0 ? 100 : 200},198) rotate(${side === 0 ? angle : -angle})`}>
        <rect x={-13} y={-8} width={26} height={len} rx={13} fill={skin} {...S} />
        <rect x={-14} y={-10} width={28} height={sleeve} rx={13} fill={shirt} {...S} />
        <circle cx={0} cy={len} r={15} fill={skin} {...S} />
        <g transform={`translate(0,${len})`}>{prop}</g>
      </g>
    );
  };

  return (
    <div style={{position: "absolute", left: x - 150 * k, top: feetY - footY * k, width: 300 * k, height: 520 * k}}>
      <svg width={300 * k} height={520 * k} viewBox="0 0 300 520" style={{overflow: "visible"}}>
        <defs>
          <pattern id="chk" width="16" height="16" patternUnits="userSpaceOnUse">
            <rect width="16" height="16" fill="#fff" />
            <rect width="8" height="16" fill="#E4572E" opacity="0.8" />
            <rect width="16" height="8" fill="#E4572E" opacity="0.8" />
          </pattern>
        </defs>
        <g transform={`translate(${jx},${bob + jy}) rotate(${leanDeg} 150 440)`}>
          {M && (
            <g>
              <rect x={178} y={206} width={66} height={88} rx={16} fill="#2FA84F" {...S} />
              <path d="M182 236H240" fill="none" {...S} />
              <rect x={196} y={250} width={30} height={26} rx={6} fill="#23893F" {...S} />
            </g>
          )}
          {[0, 1].map(Leg)}
          {M ? (
            <g>
              <rect x={100} y={276} width={100} height={58} rx={16} fill="#3B82F6" {...S} />
              <path d="M150 298V334" fill="none" {...S} />
            </g>
          ) : (
            <g>
              <path d="M100 330L200 330L212 490Q150 502 88 490Z" fill="#9AA0A6" {...S} />
              <path d="M130 366V484M170 366V484" fill="none" stroke="#7D838A" strokeWidth={3} />
            </g>
          )}
          <rect x={134} y={156} width={32} height={26} fill={skin} {...S} />
          {M ? (
            <g>
              <rect x={100} y={172} width={100} height={122} rx={28} fill="#FFD23F" {...S} />
              <path d="M132 172L150 190L168 172" fill="none" {...S} />
              <path d="M118 174L192 296" stroke={OUT} strokeWidth={16} strokeLinecap="round" fill="none" />
              <path d="M118 174L192 296" stroke="#2FA84F" strokeWidth={11} strokeLinecap="round" fill="none" />
            </g>
          ) : (
            <g>
              <path d="M92 200Q92 172 122 172H178Q208 172 208 200V340Q208 362 186 362H114Q92 362 92 340Z" fill="#fff" {...S} />
              <path d="M130 172L150 196L170 172" fill="none" {...S} />
              <path d="M150 196V310" fill="none" {...S} />
              {[214, 244, 274].map((y) => <circle key={y} cx={150} cy={y} r={3.5} fill={OUT} />)}
              <path d="M98 178L126 172L206 296L176 316Z" fill="url(#chk)" {...S} />
            </g>
          )}
          {/* কান ও মাথা */}
          <circle cx={M ? 84 : 92} cy={112} r={12} fill={skin} {...S} />
          <circle cx={M ? 216 : 208} cy={112} r={12} fill={skin} {...S} />
          <ellipse cx={150} cy={108} rx={M ? 66 : 58} ry={M ? 60 : 58} fill={skin} {...S} />
          {M ? (
            <path d="M86 96Q84 46 150 42Q216 46 214 96Q196 70 150 68Q104 70 86 96Z" fill="#1E1A1A" {...S} />
          ) : (
            <g>
              <path d="M100 80Q110 56 150 52Q190 56 200 80Q180 68 150 66Q120 68 100 80Z" fill="#F2F2F2" {...S} />
              <path d="M96 98Q86 84 98 72Q94 88 104 94Z" fill="#F2F2F2" {...S} />
              <path d="M204 98Q214 84 202 72Q206 88 196 94Z" fill="#F2F2F2" {...S} />
              <path d="M96 118Q96 198 150 204Q204 198 204 118Q186 156 150 154Q114 156 96 118Z" fill="#fff" {...S} />
            </g>
          )}
          <g transform="translate(150,108)">
            {Eye(-ex)}
            {Eye(ex)}
            {Brow(-ex, dyL, rL)}
            {Brow(ex, dyR, rR)}
            {M ? (
              <path d="M-5 12Q0 18 5 12" fill="none" {...S} />
            ) : (
              <g>
                <ellipse cx={0} cy={16} rx={8} ry={7} fill="#C98E62" {...S} />
                <path d="M-26 32Q-12 22 0 29Q12 22 26 32Q12 40 0 34Q-12 40 -26 32Z" fill="#F4F4F4" {...S} />
              </g>
            )}
            <g transform={`translate(0,${mouthY})`}>
              <Mouth expr={expr} phase={phase} />
            </g>
            {!M && (
              <g fill="rgba(255,255,255,0.25)" stroke={OUT} strokeWidth={3.5}>
                <circle cx={-22} cy={-2} r={19} />
                <circle cx={22} cy={-2} r={19} />
                <path d="M-3 -4H3M-41 -4L-52 -8M41 -4L52 -8" fill="none" />
              </g>
            )}
            {(expr === "happy" || expr === "proud") && (
              <g fill="#F28B82" opacity={0.5}>
                <ellipse cx={-42} cy={18} rx={10} ry={6} />
                <ellipse cx={42} cy={18} rx={10} ry={6} />
              </g>
            )}
            {expr === "worried" && <path d="M52 -44Q60 -30 52 -22Q44 -30 52 -44Z" fill="#7EC8F8" stroke={OUT} strokeWidth={2} />}
          </g>
          {Arm(0, armL, handL)}
          {Arm(1, armR, handR)}
        </g>
      </svg>
    </div>
  );
};
