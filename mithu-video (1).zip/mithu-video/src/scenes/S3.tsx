import React from "react";
import {AbsoluteFill} from "remotion";
import {Bush, Pond, PAPER_POS} from "../components/Backgrounds";
import {Character, Expr} from "../components/Character";
import {Icon} from "../components/Icons";
import {IP, Pill, Pop, cardStyle} from "../components/UI";
import {FONT, OUT} from "../theme";
import {tw, useT} from "../timing";

const sym = (s: string, c: string) => (
  <div style={{fontFamily: FONT, fontWeight: 700, fontSize: 110, color: c, WebkitTextStroke: "8px #222", paintOrder: "stroke fill"}}>{s}</div>
);

export const S3: React.FC = () => {
  const {f, t} = useT();
  const x = t < 59.45 ? 300 : t < 61.6 ? tw(t, 59.45, 61.6, 300, 540) : t < 64 ? 540 : tw(t, 64, 65.2, 540, 270);
  const walk = (t >= 59.45 && t < 61.6) || (t >= 64 && t < 65.2);
  const crouch = tw(t, 65.3, 65.9, 0, 200);
  const expr: Expr = t < 59.2 ? "sad" : t < 64 ? "determined" : "whisper";
  let aL = 6, aR = 6;
  let hL: React.ReactNode = null;
  let hR: React.ReactNode = null;
  if (t >= 61.7 && t < 64) {
    aL = -35; aR = -40 + 6 * Math.sin(f * 0.6);
    hL = <g transform="translate(-30,-42)"><Icon name="paper" size={64} /></g>;
    hR = <g transform="rotate(35) translate(-11,-40)"><Icon name="pencil" size={46} /></g>;
  } else if (t >= 65.3) {
    aR = -155;
  }
  return (
    <AbsoluteFill>
      <Pond mix={0} />
      <Character kind="mithu" x={x} feetY={1500 + crouch} scale={0.8} expr={expr} armL={aL} armR={aR} handL={hL} handR={hR} walk={walk} lookX={t > 64 ? 1 : 0.3} />
      <Pop x={270} y={1380} from={64.8} to={71} float={0} z={2}>
        <Bush />
      </Pop>
      <Pill from={53.7} to={56} text="সকাল" />
      <IP name="bookopen" x={560} y={1130} from={53.9} to={59.0} size={240} float={4} />
      <Pop x={150} y={900} from={56.4} to={59.0}>{sym("+", "#FF6B6B")}</Pop>
      <Pop x={470} y={840} from={56.7} to={59.0}>{sym("×", "#3B82F6")}</Pop>
      <Pop x={120} y={1090} from={57.0} to={59.0}>{sym("?", "#FFD23F")}</Pop>
      <Pop x={520} y={1010} from={57.3} to={59.0}>{sym("÷", "#3BB273")}</Pop>
      <Pop x={540} y={650} from={61.9} to={64.0} float={0} rot={-3}>
        <div style={{...cardStyle(860), background: "#FFFDF5", fontSize: 84, color: "#2B5DAE", border: `8px solid ${OUT}`}}>
          <span>একশোতে একশো চাই</span>
        </div>
      </Pop>
      <IP name="paper" x={PAPER_POS.x + 90} y={1190} from={64.0} to={71} size={130} float={4} />
      <IP name="eye" x={300} y={960} from={67.0} to={69.8} size={150} />
    </AbsoluteFill>
  );
};
