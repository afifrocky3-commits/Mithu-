import React from "react";
import {AbsoluteFill} from "remotion";
import {Pond} from "../components/Backgrounds";
import {Character, Expr} from "../components/Character";
import {Icon} from "../components/Icons";
import {IP, Pop} from "../components/UI";
import {OUT} from "../theme";
import {tw, useT} from "../timing";
import {Lathi} from "./S4";

export const S5a: React.FC = () => {
  const {f, t} = useT();
  const mix = tw(t, 100, 110, 1, 2);
  const mFeet = tw(t, 100.4, 101.4, 1500, 1640);
  const dFeet = tw(t, 102.8, 104, 1500, 1670);
  const sat = t >= 101.4;
  const mexpr: Expr = t < 106.8 ? "neutral" : t < 112 ? "determined" : "happy";
  const writing = t >= 110.77;
  const mAR = sat ? (writing ? -34 + 7 * Math.sin(f * 0.7) : -30) : 6;
  const dAL = t >= 103.9 ? (t >= 107.4 ? 65 : 55) : 6;
  const flicker = 0.5 + 0.1 * Math.sin(f * 0.6);
  const beam = tw(t, 107.4, 108.4);
  return (
    <AbsoluteFill>
      <Pond mix={mix} />
      <Character
        kind="mithu" x={330} feetY={mFeet} scale={0.8} expr={mexpr} lean={t < 100 ? 4 : 0}
        armL={sat ? -30 : 6} armR={mAR}
        handR={t >= 106.8 ? <g transform="rotate(35) translate(-11,-40)"><Icon name="pencil" size={46} /></g> : null}
      />
      <Character
        kind="dadu" x={740} feetY={dFeet} expr="happy" seed={3}
        armL={dAL} armR={0}
        handL={t >= 107.4 ? <g transform="rotate(-125) translate(-40,-12)"><Icon name="torch" size={80} /></g> : null}
        handR={<Lathi />}
      />
      {/* শিকড়ের ঢিবি — বসে থাকার ভঙ্গি */}
      <div style={{position: "absolute", inset: 0, transform: `translateY(${tw(t, 100.3, 101.5, 420, 0)}px)`}}>
        <svg width={1080} height={1920} viewBox="0 0 1080 1920">
          <path d="M-10 1920V1470Q200 1330 420 1370Q650 1300 820 1360Q980 1320 1090 1400V1920Z" fill="#8B5E3C" stroke={OUT} strokeWidth={6} />
          <path d="M120 1480Q300 1420 460 1500M600 1440Q780 1400 960 1470" stroke={OUT} opacity={0.3} strokeWidth={6} fill="none" />
        </svg>
      </div>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", inset: 0, opacity: beam * flicker}}>
        <defs>
          <linearGradient id="beam" x1="1" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#FFF6AA" stopOpacity={0.85} />
            <stop offset="1" stopColor="#FFF6AA" stopOpacity={0.1} />
          </linearGradient>
        </defs>
        <polygon points="450,1170 110,1330 430,1570" fill="url(#beam)" />
      </svg>
      <Pop x={tw(t, 99.6, 101.4, 470, 330)} y={tw(t, 99.6, 101.4, 1190, 1375)} from={99.6} to={113.8} float={2}>
        <Icon name="book" size={230} />
      </Pop>
      <Pop x={tw(t, 104, 105.8, 640, 380)} y={tw(t, 104, 105.8, 1180, 1335)} from={104} to={106.8} float={0} rot={-30}>
        <Icon name="pencil" size={120} />
      </Pop>
      <IP name="check" x={190} y={1170} from={111.6} to={113.8} size={110} />
      <IP name="check" x={480} y={1240} from={112.4} to={113.8} size={90} />
    </AbsoluteFill>
  );
};
