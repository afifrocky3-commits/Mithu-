import React from "react";
import {AbsoluteFill} from "remotion";
import {Pond} from "../components/Backgrounds";
import {Character, Expr} from "../components/Character";
import {Bubble, Camera, IP, NameBadge, Pill, Pop, Ring} from "../components/UI";
import {tw, useT} from "../timing";

export const S1: React.FC = () => {
  const {t} = useT();
  const talk = t > 1.08 && t < 5.45;
  const expr: Expr = t < 5.8 ? "worried" : t < 20.6 ? "neutral" : "worried";
  const arm = t < 5.7 ? -35 : tw(t, 5.8, 6.8, -35, 6);
  const zoom = tw(t, 0, 5.6, 1.15, 1);
  return (
    <AbsoluteFill>
      <Camera zoom={zoom} ox={360} oy={1100}>
        <Pond mix={0} />
        <Character kind="mithu" x={360} feetY={1500} scale={0.8} expr={expr} talking={talk} armL={arm} armR={arm} lookX={t > 5.8 ? 0.6 : 0} />
      </Camera>
      <Pill from={0.2} to={4.8} text="গ্রামের পুকুরপাড়" />
      <Bubble from={1.0} to={5.6} tipX={360} tipY={880} w={900} bg="#FFF7D6" text="গাছ, তুমি যদি সত্যিই জাদুর হও, তাহলে আমাকে অঙ্কে পাশ করিয়ে দাও!" />
      <IP name="sparkle" x={800} y={560} from={6.2} to={12.2} size={110} />
      <IP name="sparkle" x={960} y={700} from={6.8} to={12.2} size={80} />
      <IP name="sparkle" x={640} y={640} from={7.4} to={12.2} size={90} />
      <Pop x={360} y={800} from={12.9} to={16.0}>
        <NameBadge text="মিঠু · ৮ বছর" color="#FF7A59" />
      </Pop>
      <Ring x={458} y={1196} from={16.1} to={17.9} />
      <IP name="calendar" x={700} y={1050} from={18.3} to={20.4} size={200} label="৩" rot={6} />
      <IP name="book" x={150} y={1050} from={20.6} to={23.3} size={190} rot={-8} />
    </AbsoluteFill>
  );
};
