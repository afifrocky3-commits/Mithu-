import React from "react";
import {AbsoluteFill} from "remotion";
import {Bush, Pond} from "../components/Backgrounds";
import {Character, Expr} from "../components/Character";
import {Icon} from "../components/Icons";
import {Bubble, Camera, IP, NameBadge, Pill, Pop} from "../components/UI";
import {OUT} from "../theme";
import {tw, useT} from "../timing";

export const Lathi: React.FC = () => (
  <g>
    <rect x={-4} y={-30} width={9} height={330} rx={4} fill="#C9A15A" stroke={OUT} strokeWidth={2.5} />
    <path d="M-4 40H5M-4 120H5M-4 200H5" stroke={OUT} strokeWidth={2.5} />
  </g>
);

export const S4: React.FC = () => {
  const {t} = useT();
  const mx = t < 83.5 ? 270 : tw(t, 83.5, 84.6, 270, 370);
  const crouch = t < 83.5 ? 200 : tw(t, 83.5, 84.4, 200, 0);
  const mwalk = t >= 83.5 && t < 84.6;
  const mexpr: Expr = t < 83.5 ? "whisper" : t < 89.6 ? "surprised" : "worried";
  const mtalk = (t > 87.9 && t < 88.48) || (t > 88.92 && t < 89.37);
  const dx = tw(t, 70.4, 75.6, 1450, 760);
  const dwalk = t >= 70.4 && t < 75.7;
  const dtalk = (t > 89.9 && t < 92.4) || (t > 93.1 && t < 97.3);
  const dexpr: Expr = t < 89.8 ? "neutral" : "happy";
  const shake = t > 85.3 && t < 87.2 ? 6 : 0;
  const zoom = t < 76.4 ? 1 : t < 77.2 ? tw(t, 76.4, 77.2, 1, 1.4) : t < 79.8 ? 1.4 : tw(t, 79.8, 80.6, 1.4, 1);
  const hasPaper = t >= 80.5;

  const mithu = (
    <Character kind="mithu" x={mx} feetY={1500 + crouch} scale={0.8} expr={mexpr} talking={mtalk} armR={t < 83.5 ? -155 : 6} walk={mwalk} lookX={0.8} shake={shake ? 3 : 0} seed={2} />
  );
  const bush = (
    <div style={{position: "absolute", left: 10, top: 1230}}>
      <Bush />
    </div>
  );
  return (
    <AbsoluteFill>
      <Camera zoom={zoom} ox={760} oy={900} shake={shake}>
        <Pond mix={1} />
        <Character
          kind="dadu" x={dx} feetY={1500} expr={dexpr} talking={dtalk} walk={dwalk}
          armL={hasPaper ? -35 : 6} armR={0}
          handL={hasPaper ? <g transform="translate(-30,-42)"><Icon name="paper" size={64} /></g> : null}
          handR={<Lathi />}
        />
        {t < 83.5 ? <>{mithu}{bush}</> : <>{bush}{mithu}</>}
        <Pop x={760} y={540} from={76.6} to={80.1} float={0}>
          <NameBadge text="দাদু · ৬৮ বছর" color="#6C5CE7" />
        </Pop>
      </Camera>
      <Pill from={70.5} to={74.3} text="সন্ধ্যা" color="#FFE0B2" />
      <IP name="exclaim" x={450} y={760} from={85.3} to={87.4} size={150} />
      <Bubble from={87.7} to={89.6} tipX={390} tipY={850} w={560} bg="#FFF7D6" text="দাদু, তুমি?" />
      <Bubble from={89.7} to={92.9} tipX={760} tipY={580} w={880} bg="#EAF4FF" text="গাছ তোমার ইচ্ছে শুনতে পারে, মিঠু।" />
      <Bubble from={93.0} to={97.6} tipX={760} tipY={580} w={900} bg="#EAF4FF" text="কিন্তু অঙ্ক তো কষতে পারে না, ওটা তোমার হাতের কাজ।" />
    </AbsoluteFill>
  );
};
