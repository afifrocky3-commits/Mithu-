import React from "react";
import {AbsoluteFill} from "remotion";
import {Pond} from "../components/Backgrounds";
import {Character, Expr} from "../components/Character";
import {Icon} from "../components/Icons";
import {IP, Pill, Pop, cardStyle} from "../components/UI";
import {FONT} from "../theme";
import {tw, useT} from "../timing";

export const S2: React.FC = () => {
  const {f, t} = useT();
  const mix = t < 47 ? 0 : tw(t, 47, 51, 0, 2);
  let expr: Expr = "happy";
  let aL = 6, aR = 6, shake = 0;
  let hL: React.ReactNode = null;
  let hR: React.ReactNode = null;
  if (t < 27.6) {
    aL = -35; aR = -40 + 6 * Math.sin(f * 0.6);
    hL = <g transform="translate(-30,-42)"><Icon name="paper" size={64} /></g>;
    hR = <g transform="rotate(35) translate(-11,-40)"><Icon name="pencil" size={46} /></g>;
  } else if (t < 31) {
    aR = 110;
  } else if (t < 34.6) {
    expr = "surprised"; aL = 150; aR = 150; shake = 3;
  } else if (t < 40.2) {
    expr = t < 36 ? "surprised" : "happy"; aR = 110;
  } else if (t < 43.3) {
    expr = "worried"; aL = -30; aR = -155;
  } else if (t < 48.4) {
    expr = "worried"; aL = 55; aR = 55;
  } else {
    expr = "sleep";
  }
  return (
    <AbsoluteFill>
      <Pond mix={mix} />
      <Character kind="mithu" x={360} feetY={1500} scale={0.8} expr={expr} armL={aL} armR={aR} handL={hL} handR={hR} shake={shake} lookX={0.5} />
      <Pill from={31.1} to={34.3} text="পরদিন সকাল" />
      <Pill from={48.6} to={52.0} text="রাত" color="#CFD8FF" />
      {/* কাগজ ঝুরিতে বাঁধা */}
      <Pop x={tw(t, 27.6, 29.2, 440, 612)} y={tw(t, 27.6, 29.2, 1170, 1262)} from={27.6} to={31.0} float={0}>
        <Icon name="paper" size={130} />
      </Pop>
      <IP name="question" x={612} y={1190} from={31.2} to={34.4} size={150} />
      <IP name="bag" x={612} y={1285} from={34.69} to={53.7} size={210} float={5} />
      <IP name="book" x={780} y={1150} from={36.4} to={40.3} size={170} />
      <Pop x={540} y={650} from={40.3} to={42.9} float={0}>
        <div style={{...cardStyle(880), fontSize: 76}}>
          <Icon name="question" size={150} />
          <span>কাগজটা গেল কোথায়?</span>
        </div>
      </Pop>
      <IP name="book" x={700} y={1245} from={44.7} to={53.7} size={150} float={0} z={1} />
      <IP name="pillow" x={700} y={1295} from={45.4} to={53.7} size={280} float={0} z={2} />
      <IP name="zzz" x={480} y={840} from={49.2} to={53.6} size={130} />
      <IP name="zzz" x={540} y={730} from={50.8} to={53.6} size={100} />
      <IP name="sparkle" x={780} y={700} from={50.5} to={53.6} size={100} />
      <IP name="sparkle" x={930} y={600} from={51.2} to={53.6} size={80} />
      <div style={{fontFamily: FONT}} />
    </AbsoluteFill>
  );
};
