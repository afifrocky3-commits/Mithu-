import React from "react";
import {AbsoluteFill} from "remotion";
import {MGBg} from "../components/Backgrounds";
import {Icon} from "../components/Icons";
import {IP, Pop, Words, cardStyle} from "../components/UI";
import {FONT, OUT, bn} from "../theme";
import {tw, useT} from "../timing";

export const S5b: React.FC = () => {
  const {t} = useT();
  const n = Math.round(tw(t, 118.0, 119.2, 0, 78));
  return (
    <AbsoluteFill>
      <MGBg />
      {/* রোজ সন্ধ্যায় — সাত দিনের টিক */}
      <Pop x={540} y={900} from={113.7} to={117.4} float={0}>
        <div style={{...cardStyle(940), gap: 40}}>
          <div style={{display: "flex", gap: 18}}>
            {[1, 2, 3, 4, 5, 6, 7].map((i) => {
              const on = t > 114.0 + i * 0.45;
              return (
                <div key={i} style={{width: 104, height: 104, borderRadius: "50%", border: `6px solid ${OUT}`, background: on ? "#3BB273" : "#fff", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FONT, fontWeight: 700, fontSize: 56}}>
                  {on ? <Icon name="check" size={84} /> : bn(i)}
                </div>
              );
            })}
          </div>
          <div style={{display: "flex", gap: 50}}>
            <Icon name="moon" size={150} />
            <Icon name="tree" size={150} />
            <Icon name="bookopen" size={150} />
          </div>
        </div>
      </Pop>
      {/* ৭৮ স্কোর কার্ড */}
      <Pop x={540} y={880} from={117.7} to={120.6} float={0}>
        <div style={{...cardStyle(900), gap: 10}}>
          <span style={{fontSize: 60}}>অঙ্ক পরীক্ষার ফল</span>
          <div style={{display: "flex", alignItems: "baseline", gap: 12}}>
            <span style={{fontSize: 270, color: "#E85D5D", lineHeight: 1.1}}>{bn(n)}</span>
            <span style={{fontSize: 90}}>/{bn(100)}</span>
          </div>
          <div style={{width: 700, height: 44, border: `6px solid ${OUT}`, borderRadius: 30, background: "#fff", overflow: "hidden"}}>
            <div style={{width: `${tw(t, 118.0, 119.2, 0, 78)}%`, height: "100%", background: "#3BB273"}} />
          </div>
        </div>
      </Pop>
      <IP name="check" x={880} y={560} from={119.2} to={120.6} size={170} />
      <IP name="star" x={220} y={600} from={119.0} to={120.6} size={120} />
      <IP name="star" x={820} y={1300} from={119.3} to={120.6} size={100} />
      {/* খাতা ঝুরির সামনে */}
      <IP name="tree" x={690} y={980} from={120.7} to={124.4} size={640} float={0} />
      <Pop x={tw(t, 120.8, 122.4, 260, 470)} y={tw(t, 120.8, 122.4, 1350, 1060)} from={120.8} to={124.4} float={0} rot={-8}>
        <Icon name="notebook" size={330} />
      </Pop>
      <IP name="sparkle" x={580} y={560} from={122.2} to={124.4} size={110} />
      <IP name="heart" x={830} y={650} from={122.6} to={124.4} size={110} />
      {/* শেষ শিক্ষা */}
      <IP name="pencil" x={540} y={520} from={124.6} to={132.7} size={300} rot={20} />
      <IP name="sparkle" x={360} y={470} from={127.3} to={132.7} size={100} />
      <IP name="sparkle" x={730} y={500} from={127.8} to={132.7} size={90} />
      <Pop x={540} y={1010} from={124.5} to={132.7} float={0}>
        <div style={{...cardStyle(920), background: "#1E4D4A", gap: 36, padding: 56}}>
          <Words text="জাদুর গাছ শুধু ইচ্ছেটা শুনতে পারে," from={124.55} to={126.8} size={74} hi={["ইচ্ছেটা"]} />
          <Words text="কিন্তু ইচ্ছেকে সত্যি করার জাদু লুকিয়ে থাকে নিজের হাতের পেনসিলের ডগায়।" from={127.3} to={131.8} size={66} hi={["পেনসিলের", "ডগায়"]} />
        </div>
      </Pop>
    </AbsoluteFill>
  );
};
