import {loadFont} from "@remotion/google-fonts/HindSiliguri";
const {fontFamily} = loadFont("normal", {weights: ["500", "700"], subsets: ["bengali", "latin"]});
export const FONT = fontFamily;
export const OUT = "#222222";
export const SW = 2.5;
export const bn = (n: number | string) => String(n).replace(/\d/g, (d) => "০১২৩৪৫৬৭৮৯"[Number(d)]);
