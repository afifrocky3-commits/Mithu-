import React from "react";
import {AbsoluteFill, Audio, Composition, staticFile} from "remotion";
import {Caption} from "./components/UI";
import {FPS, H, Scene, TOTAL, W} from "./timing";
import {FONT} from "./theme";
import {S1} from "./scenes/S1";
import {S2} from "./scenes/S2";
import {S3} from "./scenes/S3";
import {S4} from "./scenes/S4";
import {S5a} from "./scenes/S5a";
import {S5b} from "./scenes/S5b";

export const MithuVideo: React.FC = () => (
  <AbsoluteFill style={{background: "#000", fontFamily: FONT}}>
    <Scene from={0} to={23.44}><S1 /></Scene>
    <Scene from={23.44} to={53.63}><S2 /></Scene>
    <Scene from={53.63} to={70.38}><S3 /></Scene>
    <Scene from={70.38} to={97.87}><S4 /></Scene>
    <Scene from={97.87} to={113.6}><S5a /></Scene>
    <Scene from={113.6} to={132.6}><S5b /></Scene>
    <Caption />
    <Audio src={staticFile("voice.mp3")} />
  </AbsoluteFill>
);

export const RemotionRoot: React.FC = () => (
  <Composition id="MithuVideo" component={MithuVideo} durationInFrames={TOTAL} fps={FPS} width={W} height={H} />
);
